# price-oracle-feed

A basic on-chain price oracle feed mock, useful as a starting point for protocols that consume external price data.

## Features
- Owner-settable price feed
- Simple getter for protocols to read
- Easy to swap with a real oracle later

## Tech Stack
- Solidity
- Hardhat
- Node.js
